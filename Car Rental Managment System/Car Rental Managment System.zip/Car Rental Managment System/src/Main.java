import java.sql.*;
import java.util.Scanner;

public class Main {

    public static void  main(String[] args) throws SQLException {
        Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/postgres" , "postgres" , "1234");
        Statement statement = connection.createStatement();
        Scanner in = new Scanner(System.in);
        System.out.println("enter name");
        String name = in.nextLine();
        System.out.println("enter age");
        int age = in.nextInt();
        System.out.println("enter gender");
        String gender = in.next();
        System.out.println("enter balance");
        int balance = in.nextInt();
        PreparedStatement preparedStatement = connection.prepareStatement("insert into test(name,age,gender,balance) values (?,?,?,?)");
        preparedStatement.setString(1,name);
        preparedStatement.setInt(2,age);
        preparedStatement.setString(3,gender);
        preparedStatement.setInt(4,balance);
        preparedStatement.executeUpdate();

        System.out.println("user added");

        ResultSet resultSet = statement.executeQuery("select * from test");
        while (resultSet.next()){
            System.out.println("id:" + resultSet.getInt("id")
            + " name: " + resultSet.getString("name")+ "age"+ resultSet.getInt("age")+"gender"+resultSet.getString("gender")+"balance"+ resultSet.getInt("balance"));
        }
    }
}